function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(400,10,125);
  fill(150, 75, 0)
  //rect(145, 90, 215, 315, 20);
  ellipse(250, 225, 300, 290);
  
  fill(255, 204, 0)
  triangle(75, 450, 250, 275, 450, 450);
  fill(250, 175, 100);
  rect(195, 250, 115, 125, 20);
  fill(250, 175, 100);
  circle(250, 200, 175);
  fill(150,200,170);
  circle(205,190,80);
  circle(295, 190, 80);
  fill(0,0,0);
  circle(295, 190, 20);
  circle(205, 190, 20);
  line(220, 205, 205, 185);
  line(210, 210, 205, 185);
  line(200, 210, 205, 185);
  line(190, 205, 205, 185);
  
  line(310, 205, 295, 185);
  line(300, 210, 295, 185);
  line(290, 210, 295, 185);
  line(280, 205, 295, 185);
  
  point(205, 250);
  point(215, 235);
  point(230, 250);
  fill(250, 150, 100)
  ellipse(250, 225, 45, 25);
  noFill();
arc(250, 215, 25, 20, PI+QUARTER_PI, TWO_PI);
  arc(250, 250, 50, 45, 0, PI, OPEN);
  strokeWeight(5);
  
  fill(0,0,0);
  text('Grace Caufield Self Portrait', 50, 50);
  textSize(32);
  text('g.caufield', 350, 490);
}
